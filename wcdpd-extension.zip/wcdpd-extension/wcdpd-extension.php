<?php
/*
* Plugin Name: WooCommerce Dynamic Pricing & Discounts Extension
* Plugin URI: https://example.com
* Description: Output discounted prices on product card and singple product page.
* Version: 1.0
* Requires at least: 5.2
* Requires PHP: 7.2
* Author: Mahim Zaman
* Author URI: https://www.mahimzaman.com
* License: GPL v2 or later
* License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: wdpde-plugin
*/
if(!defined('ABSPATH')){
    exit;
}

class WDPDE_Extension{
    function __construct()
    {
        add_action('woocommerce_shop_loop_item_title', array($this, 'wdpde_grid_price'), 10 );

        add_action('wp_enqueue_scripts', array($this, 'wdpde_scripts'));

        add_filter( 'woocommerce_get_price_html', array($this, 'wdpde_single_product_price'), 10, 2 );

        add_filter( 'woocommerce_cart_item_price', array($this, 'wdpde_cart_item_filter'), 10, 3 );

        add_filter( 'woocommerce_cart_item_subtotal', array($this, 'wdpde_cart_item_subtotal_filter'), 10, 3 );

        add_filter('woocommerce_cart_item_thumbnail', array($this, 'wdpde_cart_item_percent'), 10, 3);

        add_filter('body_class', array($this, 'wdpde_body_class'));

        add_filter('woocommerce_cart_subtotal', array($this, 'wdpde_cart_subtotal'), 10, 3);

        add_filter('rp_wcdpd_promotion_total_saved_formatted_amount', array($this, 'wdpde_cart_sale_label'));

        add_action('wp_ajax_wdpde_handle_menu_cart', array($this, 'wdpde_handle_menu_cart'));
        
        add_action('wp_ajax_nopriv_wdpde_handle_menu_cart', array($this, 'wdpde_handle_menu_cart'));
}

    function wdpde_scripts(){
        global $woocommerce;
        wp_enqueue_style( 'wdpde_style', plugin_dir_url(__FILE__) . '/assets/css/style.css', array(), null );
        wp_enqueue_script( 'wdpde_script', plugin_dir_url(__FILE__) . '/assets/js/script.js', array(), null, true );

        wp_localize_script( 'wdpde_script', 'wdpde_local', array(
            'admin_url' => admin_url( 'admin-ajax.php' ),
            'cart_total' => WC() -> cart -> cart_contents_total,
            'currency' => get_woocommerce_currency_symbol(),
        ) );

    }

    function wdpde_get_rules($id){
        global $woocommerce ;
        $product_id = $id;
        $cart_subtotal =  floatval(WC() -> cart -> get_subtotal()) ;
        $cart_discounts = RP_WCDPD_Rules::get('cart_discounts', array(), true);
        $product = wc_get_product( $product_id );
        $price = floatval($product -> get_regular_price());
        $lows = [];
        $highs = [];
        $from_method = '';
        $from_price_value = '';
        $to_method = '';
        $to_price_value = '';
        $discount_price = '';

        foreach($cart_discounts as $discount){
           foreach($discount['conditions'] as $condition){
             if($condition['method_option'] == 'at_least'){
                array_push($lows, array(
                    'value' => $condition['decimal'],
                    'pricing_method' => $discount['pricing_method'],
                    'pricing_value' => $discount['pricing_value']
                ));
             }
             elseif($condition['method_option'] == 'less_than'){
                array_push($highs, array(
                    'value' => $condition['decimal'],
                    'pricing_method' => $discount['pricing_method'],
                    'pricing_value' => $discount['pricing_value'],
                ));
             }
           }
        }

        arsort($lows);
        sort($highs);

        foreach($lows as $low){
            if($cart_subtotal >= $low['value']){
                $from_method = $low['pricing_method'];
                $from_price_value = $low['pricing_value'];
                break ;
            }
        }

        foreach($highs as $high){
            if($cart_subtotal <= $high['value']){
                $to_method = $high['pricing_method'];
                $to_price_value = $high['pricing_value'];
                break ;
            }
        }

        if($from_method == $to_method || $to_method == '' || $from_method = ''){
            if($from_method == 'discount__percentage' || $from_method == 'discount_per_cart_item__percentage'){
                $percent = $from_price_value / 100;
                $discount_price = $price - ($price * $percent);
            }
            else{
                $amount = $from_price_value ;
                $discount_price = $price - $amount ;
            }
        }

        $discount_array = array(
            'percent' => $percent * 100 . '%',
            'price' => get_woocommerce_currency_symbol() . number_format($price, 2),
            'discount_price' => get_woocommerce_currency_symbol() . number_format($discount_price,2),
            'product' => $product 
        );

        return $discount_array; 
    }

    function wdpde_grid_price(){
        $grid_price = $this -> wdpde_get_rules(get_the_ID());
        if(! $grid_price['product'] -> is_on_sale()):

            remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
        ?>
<div class="wdpde_loop_item" data-id=<?php echo get_the_ID()?>;>
    <span class="wdpde_discount_percent"><?php echo '-' .$grid_price['percent'] ;?></span>
    <div class="wdpde_product_price">
        <span class="wdpde_regular_price"><?php echo $grid_price['price'];?></span>
        <span class="wdpde_discount_price"><?php echo $grid_price['discount_price'] ;?></span>
    </div>
</div>

<?php

else:
    add_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
endif;
    }

    function wdpde_single_product_price($price_html, $product){
        ob_start();
        $grid_price = $this -> wdpde_get_rules(get_the_ID());
        if(! $grid_price['product'] -> is_on_sale() && is_singular('product')):
        ?>

<span class="wdpde_single_discount_percent"><?php echo '-' . $grid_price['percent'] ;?></span>
<div class="wdpde_single_product_price">
    <span class="wdpde_single_regular_price"><?php echo $grid_price['price'];?></span>
    <span class="wdpde_single_discount_price"><?php echo $grid_price['discount_price'] ;?></span>
</div>

<?php
else:
    echo $price_html;
endif;
return ob_get_clean();
    }

    function wdpde_cart_item_filter( $price_html, $cart_item, $cart_item_key ) {
        $grid_price = $this -> wdpde_get_rules($cart_item['product_id']);
    if(! $grid_price['product'] -> is_on_sale() && is_cart()):
    ?>

<div class="wdpde_product_price">
    <span
        class="wdpde_cart_regular_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['data'] -> get_regular_price()), 2);?></span>
    <span
        class="wdpde_cart_discount_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['data'] -> get_regular_price()) - (floatval($cart_item['data'] -> get_regular_price()) * (floatval($grid_price['percent']) / 100)), 2) ;?></span>
</div>
<?php
else:
    ?>
<div class="wdpde_product_price">
    <span
        class="wdpde_cart_regular_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['data'] -> get_regular_price()), 2);?></span>
    <span
        class="wdpde_cart_discount_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['data'] -> get_sale_price()), 2) ;?></span>
</div>
<?php
endif;
}

    function wdpde_cart_item_subtotal_filter( $subtotal, $cart_item, $cart_item_key ) {
        $grid_price = $this -> wdpde_get_rules($cart_item['product_id']);
    if(! $grid_price['product'] -> is_on_sale() && is_cart()):
    ?>

<div class="wdpde_product_price">
    <span
        class="wdpde_cart_regular_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['line_subtotal']), 2);?></span>
    <span class="wdpde_cart_discount_price">
        <?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['line_subtotal']) - (floatval($cart_item['line_subtotal']) * (floatval($grid_price['percent']) / 100)), 2) ;?></span>
</div>
<?php
else:?>
<span
    class="wdpde_cart_regular_price"><?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['data'] -> get_regular_price()) * $cart_item['quantity'], 2);?></span>
<span class="wdpde_cart_discount_price">
    <?php echo get_woocommerce_currency_symbol() . number_format(floatval($cart_item['line_subtotal']), 2) ;?></span>
<?php
endif;
}

// Add an image before the cart item thumbnail
function wdpde_cart_item_percent($product_image, $cart_item, $cart_item_key) {
    if(is_cart() && $cart_item['data'] -> is_on_sale()){
        return $product_image;
    }
    else{
    $grid_price = $this -> wdpde_get_rules($cart_item['product_id']); // Replace with your image URL
return '<span class="wdpde_cart_percent"> -'.$grid_price['percent'] . '</span>' . $product_image;
}
}

// Add body class
function wdpde_body_class($classes){
    if(is_singular( 'product' )):
    $product = wc_get_product(get_the_ID());
    if( $product -> is_on_sale()){
        $classes[] = 'wdpde_sale_product';
    }
    endif;

    return $classes;
}

function wdpde_cart_subtotal($subtotal_html, $compound, $cart){

    global $woocommerce ;
    $cart_items = $cart -> cart_contents;
    $subtotal = 0 ;
    
    foreach($cart_items as $item){
        $product = wc_get_product($item['product_id']);
        $line_subtotal = floatval($item['line_subtotal']);
        if(! $product -> is_on_sale()){
            $subtotal = floatval($subtotal + $line_subtotal);
        }        
    }

    if($subtotal == 0){
        $subtotal = '<span class="wdpde-price woocommerce-Price-amount amount">'.get_woocommerce_currency_symbol() . $subtotal .'  <span style="font-size: 12px ;">(No discount product added to cart)</span></span>';
    }
    else{
        
            $subtotal = '<span class="wdpde-price woocommerce-Price-amount amount">' . get_woocommerce_currency_symbol() . number_format($subtotal, 2) . '</span>';
    }

    return $subtotal ;
}

function wdpde_cart_sale_label(){

    global $woocommerce ;
    $cart_items = WC() -> cart -> cart_contents;
    $sale_saved = 0 ;

    
    
    foreach($cart_items as $item){
        $product = wc_get_product($item['product_id']);
        $line_subtotal = floatval($item['line_subtotal']);
        if($product -> is_on_sale()){
            $sale_saved = floatval($sale_saved + $line_subtotal);
        }        
    }

    $sale_saved = '<span class="wdpde-price woocommerce-Price-amount amount">' . get_woocommerce_currency_symbol() . number_format($sale_saved, 2) . '</span>';

    return $sale_saved ;
    
}

function wdpde_handle_menu_cart(){
    global $woocommerce ;
    $cart_items = WC() -> cart -> cart_contents;
    $cart_total = 0 ;

    if(count($cart_items) == 1){
        foreach($cart_items as $item){
            $product_id = $item['product_id'];
            $rules = $this -> wdpde_get_rules($product_id);
            $percent = $rules['percent'];
            $line_total = floatval($item['line_total']) - (floatval($item['line_total']) * ($percent/100));
            $cart_total = $cart_total + $line_total;
        }
    }
    else{
        foreach($cart_items as $item){
            $product = wc_get_product($item['product_id']);
            $line_total = floatval($item['line_total']);
            $cart_total = $cart_total + $line_total;
        }
    }     
    
    echo '<span class="woocommerce-Price-amount amount">'. get_woocommerce_currency_symbol() . number_format($cart_total, 2) .'</span>';
    die();
}


}




/**
 * Check if WooCommerce Dynamice Pricing and Discounts plugin is active or not
 *
 * @true = include it and run plugin.
 *
 * @false = show notice.
 */

if(!in_array('wc-dynamic-pricing-and-discounts/wc-dynamic-pricing-and-discounts.php', apply_filters( 'active_plugins', get_option('active_plugins')))){
    echo '<div class="wrap">
        <p class="notice notice-error">Install WooCommerce Dynamic Pricing & Discounts plugin by RightPress to use this Extension plugin.</p>
    </div>';
}
else{
    require_once(WP_PLUGIN_DIR . '/wc-dynamic-pricing-and-discounts/wc-dynamic-pricing-and-discounts.php');
    $wdpde = new WDPDE_Extension() ;
}

?>