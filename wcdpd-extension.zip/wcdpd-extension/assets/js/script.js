$ = jQuery;
$(document).ready(function () {
  $("body").on("rightpress_live_product_price_update_updated", function () {
    // Update label
    if (!$("body").hasClass("wdpde_sale_product")) {
      $(".rightpress_product_price_live_update").remove();
    }
  });

  // Ajax add to cart ;

  $(document).on("added_to_cart", function () {
    $.ajax({
      type: "post",
      url: wdpde_local.admin_url,
      data: {
        action: "wdpde_handle_menu_cart",
      },
      success: function (response) {
        $(".oxy-woo-add-to-cart").html(response);
      },
      error: function (error) {
        console.log(error.responseText);
      },
    });
  });
});
